var byId = function(id) {return document.getElementById(id)}

var val = function(id) {return document.getElementById(id).value}

