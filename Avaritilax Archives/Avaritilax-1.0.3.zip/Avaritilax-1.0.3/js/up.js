var Upgrades = '' // 0: No upgrade corresponding to that ID; 1: Upgrade exist, but locked; 2: Upgrade unlocked, but not bought; 3: Upgrade bought
var UpList;
function initup(restart){
    var startloadup = new Date().getTime();
    document.getElementById("loginload").innerHTML = "Loading upgrades"
    $.getJSON("Up.json?7", function(json) {
        UpList = json;
        Upgrades = '';
        for(var i = 0; i<=1999 ; i++){
            Upgrades += UpList[i].Implemented;
            if(UpList[i].Implemented==1){
                document.getElementById("upgrades").innerHTML += 
                '<div id="U' + toThreeDigit(i) + '" class="shopitemdisplay" style="display:none"><img class="img32px60" src="assets/images/icons-upgrades/U' + toThreeDigit(i) + '.png"><h2 class="shopitem-label">' + UpList[i].Name + '</h2><button type="button" class="shopitem-button" onclick="buyup(' + i + ')">Buy</button><br><p class="ps">' + UpList[i].Description + '</p><br><p class="ps changelog-quote">' + UpList[i].Quote + '</p><br><p>Cost: ' + toText(UpList[i].Cost,false) + '</p></div>';
            }
        }
        if(!restart){
            Upgrades = localStorage['Upgrades'] || Upgrades;
            for(var i = 0; i<=1999 ; i++){
                if(UpList[i].Implemented==1 && Upgrades[i]==0){ //update
                    Upgrades = replace(Upgrades,i,'1');
                }
                if(Upgrades[i]==2){
                    document.getElementById("U" + toThreeDigit(i)).style.display = "block";
                }
            }
        }    
        if(debug){console.log('DEBUG: Up init\'ed @'+ (new Date().getTime() - startloadup) + 'ms');}
        initachi(restart);
    });
}
function unlockup(id){
    Upgrades = replace(Upgrades,id,'2');
    document.getElementById("U" + toThreeDigit(id)).style.display = "block";
}
function buyup(id){
    if(UpList[id].Cost<=Money){
        if(UpList[id].Type=="KGPS"){
            KGPSMulti += UpList[id].Multi / 100;
        }else if(UpList[id].Type=="MPC"){
            MPCperKG += UpList[id].Multi / 10000;
        }else if(UpList[id].Type=="CRate"){
            CRate += UpList[id].Multi / 100;
        }else if(UpList[id].Type=="CDmg"){
            CDmg += UpList[id].Multi / 100;
        }else{
            Fishball.up(id);Burger.up(id);Restaurant.up(id);Factory.up(id);Farm.up(id);Asteroid.up(id);Castle.up(id);Portal.up(id);Fatconvertor.up(id);
        }
        Money-=UpList[id].Cost;
        Upgrades = replace(Upgrades,id,'3');
        document.getElementById("U" + toThreeDigit(id)).style.display = "none";
        update();
    }
}