function save(){
    if(login){
        var LastSaved = new Date();
        document.getElementById("header-lastsaved").innerHTML = "Last Saved: " + LastSaved.toLocaleDateString(undefined, DateOptions) + " " + LastSaved.toLocaleTimeString('en-US');
        localStorage.setItem("LastSaved", LastSaved);
        localStorage.setItem("KG", KG);
        localStorage.setItem("KGPS", KGPS);
        localStorage.setItem("MPCperKG", MPCperKG);
        localStorage.setItem("totalMPC", totalMPC);
        localStorage.setItem("Money", Money);
        localStorage.setItem("totalMoney", totalMoney);
        localStorage.setItem("KGPSMulti", KGPSMulti);
        localStorage.setItem("CRate", CRate);
        localStorage.setItem("CDmg", CDmg);
        localStorage.setItem("manualClicks", manualClicks);
        localStorage.setItem("autoClicks", autoClicks);
        localStorage.setItem("debug", debug);
        localStorage.setItem("TotalAmount", TotalAmount);
        Fishball.save(); Burger.save(); Restaurant.save(); Factory.save(); Farm.save(); Asteroid.save(); Castle.save(); Portal.save(); Fatconvertor.save();
        localStorage.setItem("Achievements", Achievements);
        localStorage.setItem("Upgrades", Upgrades);
        MainXP.save(); Playtime.save();
        if(debug){console.log('DEBUG: Saved');}
    }else{
        if(debug){console.log('DEBUG: Not logged in, cannot save');}
    }
}
var startload;
function load(restart){
    startload = new Date().getTime();
    document.getElementById("continue").style.display = "none";
    document.getElementById("restart").style.display = "none";
    document.getElementById("loginload").style.display = "block";
    if(!restart){   
        document.getElementById("loginload").innerHTML = "Loading in previous data"
        var LastSaved = new Date(localStorage['LastSaved']);
        document.getElementById("header-lastsaved").innerHTML = "Last Saved: " + LastSaved.toLocaleDateString(undefined, DateOptions) + " " + LastSaved.toLocaleTimeString('en-US');
        KG = Number(localStorage['KG']) || KG;
        KGPS = Number(localStorage['KGPS']) || KGPS;
        MPCperKG = Number(localStorage['MPCperKG']) || MPCperKG;
        totalMPC = Number(localStorage['totalMPC']) || totalMPC;
        Money = Number(localStorage['Money']) || Money;
        totalMoney = Number(localStorage['totalMoney']) || totalMoney;
        KGPSMulti = Number(localStorage['KGPSMulti']) || KGPSMulti;
        CRate = Number(localStorage['CRate']) || CRate;
        CDmg = Number(localStorage['CDmg']) || CDmg;
        manualClicks = Number(localStorage['manualClicks']) || manualClicks;
        autoClicks = Number(localStorage['autoClicks']) || autoClicks;
        TotalAmount = Number(localStorage['TotalAmount']) || TotalAmount;
        debug = localStorage['debug']=='true';
        if(debug){
            document.getElementById("toggledebug").innerHTML = "ON";
            console.log("DEBUG ON");
        }else{
            console.log("DEBUG OFF");
            document.getElementById("toggledebug").innerHTML = "OFF";
        }
        Fishball.load(); Burger.load(); Restaurant.load(); Factory.load(); Farm.load(); Asteroid.load(); Castle.load(); Portal.load(); Fatconvertor.load();
        MainXP.load(); Playtime.load();
        if(debug){console.log('DEBUG: Loaded in previous data');}
    }else{
        document.getElementById("loginload").innerHTML = "Restarting"
        if(debug){console.log('DEBUG: Restarted' );}
    }
    initup(restart);
}
function contload(){
    document.getElementById("loginload").innerHTML = "Finishing up"
    tick();
    const tickInterval = setInterval(tick,1000);
    document.getElementById("login").style.display = "none";
    document.getElementById("game").style.display = "block";
    update();
    navigate('basicshop')
    login = true;
    if(debug){console.log('DEBUG: loading complete @'+ (new Date().getTime() - startload) + 'ms');}
}
document.addEventListener('keydown', (event) => {
    if(event.key = 's'){
        save();
    }
} , false )