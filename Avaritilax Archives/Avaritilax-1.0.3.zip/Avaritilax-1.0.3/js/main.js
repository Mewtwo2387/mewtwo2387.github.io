function tick(){
    Playtime.tick();
    KG+=KGPS;
    if(debug){console.log('DEBUG: tick (previous tick ' + (new Date().getTime() - prevtick) + 'ms ago)');}
    prevtick = new Date().getTime();
    update();
}
function openlink(link){
    window.open(
        link,'_blank'
    );
}
function update(){
    var startupdate = new Date().getTime();
    Fishball.update(); Burger.update(); Restaurant.update(); Farm.update(); Factory.update(); Asteroid.update(); Portal.update(); Castle.update(); Fatconvertor.update();
    KGPS = Fishball.TotalKGPS + Burger.TotalKGPS + Restaurant.TotalKGPS + Factory.TotalKGPS + Farm.TotalKGPS + Asteroid.TotalKGPS + Castle.TotalKGPS + Portal.TotalKGPS + Fatconvertor.TotalKGPS;
    TotalAmount = Fishball.Amount + Burger.Amount + Restaurant.Amount + Factory.Amount + Farm.Amount + Asteroid.Amount + Castle.Amount + Portal.Amount + Fatconvertor.Amount;
    totalMPC = MPCperKG * KG;
    document.getElementById("header-playtime").innerHTML = Playtime.Days + "d " + toTwoDigit(Playtime.Hours) + ":" + toTwoDigit(Playtime.Minutes) + ":" + toTwoDigit(Playtime.Seconds);
    document.getElementById("mainxpdisplayinner").style.width = 100 * MainXP.CurrentXP / MainXP.RequiredXP;
    document.getElementById("mainxplabel").innerHTML = toText(MainXP.CurrentXP,false) + "/" + toText(MainXP.RequiredXP,false);
    document.getElementById("mainlevellabel").innerHTML = MainXP.level;
    document.getElementById("kglabel").innerHTML = toText(KG,true);
    document.getElementById("kgpslabel").innerHTML = toText(KGPS,true);
    document.getElementById("mpclabel").innerHTML = toText(totalMPC,true);
    document.getElementById("moneylabel").innerHTML = "$" + toText(Money,true);
    document.getElementById("title").innerHTML = toText(KG,true) + ' KG';
    infoupdate();
    achiupdate();
    if(debug){console.log('DEBUG: update @'+ (new Date().getTime() - startupdate) + 'ms');}
}
function snorlaxclick(event){
    const template = document.getElementById('floating-text-template').content.cloneNode(true);
    const element = template.querySelector('.floating-text');
    element.style.left = event.clientX + 'px'
    element.style.top = (event.clientY - 50) + 'px'
    manualClicks++;
    if(Math.random()>=CRate){
        Money+=totalMPC;
        totalMoney+=totalMPC;
        element.style.color="#CCCCCC"
        element.innerHTML = toText(totalMPC,true);
    }else{
        Money+=totalMPC*(1+CDmg);
        totalMoney+=totalMPC*(1+CDmg);
        element.style.color="#FF5555"
        element.innerHTML = toText(totalMPC*(1+CDmg),true);
    }
    document.getElementById('game').appendChild(element);
    update();
    setTimeout(function(){
        element.remove();
    },5000);
}
function navigate(tab){
    var items = document.getElementsByClassName("tab");
    for (var i=0; i < items.length; i++) {
        items[i].style.display = "none";
    }
    document.getElementById(tab).style.display = "block";
}
function newnotifs(icon,header,name,desc){
    notifs++;
    if(notifs<=3){
        document.getElementById("notifs" + notifs).style.display = "block";
        document.getElementById("notifs" + notifs + "icon").src = icon;
        document.getElementById("notifs" + notifs + "header").innerHTML = header;
        document.getElementById("notifs" + notifs + "name").innerHTML = name;
        document.getElementById("notifs" + notifs + "desc").innerHTML = desc;
    }else{
        document.getElementById("notifsmore").style.display = "block";
        document.getElementById("notifsmorecontent").innerHTML = "+" + (notifs - 3) + " more";
        document.getElementById("notifs1icon").src = document.getElementById("notifs2icon").src;
        document.getElementById("notifs1header").innerHTML = document.getElementById("notifs2header").innerHTML;
        document.getElementById("notifs1name").innerHTML = document.getElementById("notifs2name").innerHTML;
        document.getElementById("notifs1desc").innerHTML = document.getElementById("notifs2desc").innerHTML;
        document.getElementById("notifs2icon").src = document.getElementById("notifs3icon").src;
        document.getElementById("notifs2header").innerHTML = document.getElementById("notifs3header").innerHTML;
        document.getElementById("notifs2name").innerHTML = document.getElementById("notifs3name").innerHTML;
        document.getElementById("notifs2desc").innerHTML = document.getElementById("notifs3desc").innerHTML;
        document.getElementById("notifs3icon").src = icon;
        document.getElementById("notifs3header").innerHTML = header;
        document.getElementById("notifs3name").innerHTML = name;
        document.getElementById("notifs3desc").innerHTML = desc;
    }
    document.getElementById("notifscross").style.display = "block";
}
function clearnotifs(){
    notifs = 0;
    document.getElementById("notifsmore").style.display = "none";
    document.getElementById("notifs1").style.display = "none";
    document.getElementById("notifs2").style.display = "none";
    document.getElementById("notifs3").style.display = "none";
    document.getElementById("notifscross").style.display = "none";
}
function toggledebug(){
    debug = !debug;
    if(debug){
        document.getElementById("toggledebug").innerHTML = "ON";
        console.log("DEBUG ON");
    }else{
        console.log("DEBUG OFF");
        document.getElementById("toggledebug").innerHTML = "OFF";
    }
}
function infoupdate(){
    document.getElementById("infoKG").innerHTML = toText(KG,true);
    document.getElementById("infoMoney").innerHTML = toText(Money,true);
    document.getElementById("infoTMoney").innerHTML = toText(totalMoney,true);
    document.getElementById("infoRKGPS").innerHTML = toText(KGPS/KGPSMulti,true);
    document.getElementById("infoMKGPS").innerHTML = '+' + toText((KGPSMulti - 1)*100,true) + '%';
    document.getElementById("infoTKGPS").innerHTML = toText(KGPS,true);
    document.getElementById("infoRMPC").innerHTML = toText(KG/100,true);
    document.getElementById("infoMMPC").innerHTML = '+' + toText((MPCperKG - 0.01)*10000,true) + '%';
    document.getElementById("infoTMPC").innerHTML = toText(totalMPC,true);
    document.getElementById("infoShop").innerHTML = toText(TotalAmount,false);
    document.getElementById("infoCRate").innerHTML = toText(CRate*100 ,true) + '%';
    document.getElementById("infoCDmg").innerHTML = '+' + toText(CDmg*100 ,true) + '%';
    document.getElementById("infoMClick").innerHTML = toText(manualClicks, false);
}