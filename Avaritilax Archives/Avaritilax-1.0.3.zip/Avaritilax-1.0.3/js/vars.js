//Main
var KG = 100;
var KGPS = 0;
var MPCperKG = 0.01;
var totalMPC = 1;
var Money = 0;
var totalMoney = 0;
var KGPSMulti = 1;
var CRate = 0;
var CDmg = 0.5;
var TotalAmount = 0;
//Main misc
var login = false;
var debug = false;
var prevtick = new Date().getTime();
var notifs = 0;
//stats
var manualClicks = 0;
var autoClicks = 0;

// Food
var Fishball = new MainShopFood('fishball',0.2, 15);
var Burger = new MainShopFood('burger',1.2, 100);
var Restaurant = new MainShopFood('restaurant',8, 2500);
var Factory = new MainShopFood('factory',40, 55000);
var Farm = new MainShopFood('farm',200, 850000);
var Castle = new MainShopFood('castle',900, 10e6);
var Asteroid = new MainShopFood('asteroid',4400, 150e6);
var Portal = new MainShopFood('portal',177013, 2.8e9);
var Fatconvertor = new MainShopFood('fatconvertor',777000, 44e9);

//time
const DateOptions = { year: 'numeric', month: 'long', day: 'numeric' , timeZoneName: 'short' };
var Playtime = new Timer('Playtime',0,0,0,0);

//XP
var MainXP = new XP('MainXP',100);

//Settings
var shortennumbers = true;
const suffix = ['K','M','B','T','Qa','Qi','Sx','Sp','Oc','No','De','UD','DD','TD','QaD','QiD','SxD','SpD','OcD','NoD','Vi','UV','DV','TV','QaV','QiV','SxV','SpV','OcV','NoV','Tg']
const word = ['Thousand','Million','Billion','Trillion','Quadrillion','Quintillion','Sextillion','Septillion','Octillion','Nonillion','Decillion','Uundecillion','Duodecillion','Tredecillion','Quattourdecillion','Quindecillion','Sexdecillion','Septendecillion','Octodecillion','Novemdecillion','Vigintillion','Unvigintillion','Duovigintillion','Trevigintillion','Quattourvigintillion','Quinvigintillion','Sexvigintillion','Septenvigintillion','Octovigintillion','Novemvigintillion','Trigintillion']