class MainShopFood{
    AdditionalKGPSMulti = 1;
    AdditionalCostMulti = 1;
    rawAmount = 0;
    AdditionalAmount = 0;
    Amount = 0;
    TotalKGPS = 0;

    constructor(Name,KGPS,Cost) {
        this.Name = Name;
        this.rawKGPS = KGPS;
        this.KGPS = KGPS;
        this.rawCost = Cost;
        this.Cost = Cost;
    }

    update(){
        this.KGPS = this.rawKGPS * this.AdditionalKGPSMulti * KGPSMulti;
        this.Cost = this.rawCost * this.AdditionalCostMulti;
        this.Amount = this.rawAmount + this.AdditionalAmount;
        this.TotalKGPS = this.KGPS * this.Amount; 
        document.getElementById(this.Name + "display").innerHTML = "Cost: " + toText(this.Cost,true) + " KGPS: " + toText(this.KGPS,true);
        document.getElementById(this.Name + "display2").innerHTML = "KGPS: " + toText(this.TotalKGPS,true);
        document.getElementById(this.Name + "countdisplay").innerHTML = this.Amount;
        document.getElementById(this.Name + "percent").style.width = Math.min(Money/this.Cost,1) * 300;
        if(Money<this.Cost){
            document.getElementById(this.Name + "percent").style.backgroundColor = 'rgb(0, 150, 96)';
        }else{
            document.getElementById(this.Name + "percent").style.backgroundColor = 'rgb(0, 210, 132)';
        }
        for(var i = 0; i<=1999 ; i++){
            if(Achievements[i]==1 && AchiList[i].Type==this.Name && this.Amount>=AchiList[i].Amount){
                unlockachi(i);
            }
        }    
    }
    buy(){
        if(Money>=this.Cost){
            Money -= this.Cost;
            this.rawAmount++;
            this.rawCost *= 1.2;
            update();
            return true;
        }else{
            return false;
        }
    }
    load(){
        this.rawKGPS = Number(localStorage[this.Name + "rawKGPS"]) || this.rawKGPS;
        this.AdditionalKGPSMulti = Number(localStorage[this.Name + "AdditionalKGPSMulti"]) || this.AdditionalKGPSMulti;
        this.KGPS = Number(localStorage[this.Name + "KGPS"]) || this.KGPS;
        this.rawCost = Number(localStorage[this.Name + "rawCost"]) || this.rawCost;
        this.AdditionalCostMulti = Number(localStorage[this.Name + "AdditionalCostMulti"]) || this.AdditionalCostMulti;
        this.Cost = Number(localStorage[this.Name + "Cost"]) || this.Cost;
        this.rawAmount = Number(localStorage[this.Name + "rawAmount"]) || this.rawAmount;
        this.AdditionalAmount = Number(localStorage[this.Name + "AdditionalAmount"]) || this.AdditionalAmount;
        this.Amount = Number(localStorage[this.Name + "Amount"]) || this.Amount;
        this.TotalKGPS = Number(localStorage[this.Name + "TotalKGPS"]) || this.TotalKGPS;
    }
    save(){
        localStorage.setItem(this.Name + "rawKGPS" , this.rawKGPS);
        localStorage.setItem(this.Name + "AdditionalKGPSMulti" , this.AdditionalKGPSMulti);
        localStorage.setItem(this.Name + "KGPS" , this.KGPS);
        localStorage.setItem(this.Name + "rawCost" , this.rawCost);
        localStorage.setItem(this.Name + "AdditionalCostMulti" , this.AdditionalCostMulti);
        localStorage.setItem(this.Name + "Cost" , this.Cost);
        localStorage.setItem(this.Name + "rawAmount" , this.rawAmount);
        localStorage.setItem(this.Name + "AdditionalAmount" , this.AdditionalAmount);
        localStorage.setItem(this.Name + "Amount" , this.Amount);
        localStorage.setItem(this.Name + "TotalKGPS" , this.TotalKGPS);
    }
    up(id){
        if(UpList[id].Type==this.Name){
            this.AdditionalKGPSMulti *= UpList[id].Multi;
        }else if(UpList[id].Type==(this.Name + 'cost')){
            this.AdditionalCostMulti *= UpList[id].Multi;
        }
    }
}
class Timer{
    constructor(Name,Days,Hours,Minutes,Seconds){
        this.Name = Name;
        this.Days = Days;
        this.Hours = Hours;
        this.Minutes = Minutes;
        this.Seconds = Seconds;
        this.TotalSeconds = 86400*Days + 3600*Hours + 60*Minutes + Seconds;
    }
    toDHMS(){
        this.Days = Math.floor(this.TotalSeconds/86400);
        this.Hours = Math.floor((this.TotalSeconds%86400)/3600);
        this.Minutes = Math.floor((this.TotalSeconds%3600)/60);
        this.Seconds = Math.floor(this.TotalSeconds%60);
    }
    tick(){
        this.TotalSeconds++;
        this.toDHMS();
    }
    load(){
        this.Days = Number(localStorage[this.Name + "Days"]) || this.Days;
        this.Hours = Number(localStorage[this.Name + "Hours"]) || this.Hours;
        this.Minutes = Number(localStorage[this.Name + "Minutes"]) || this.Minutes;
        this.Seconds = Number(localStorage[this.Name + "Seconds"]) || this.Seconds;
        this.TotalSeconds = Number(localStorage[this.Name + "TotalSeconds"]) || this.TotalSeconds;
    }
    save(){
        localStorage.setItem(this.Name + "Days" , this.Days);
        localStorage.setItem(this.Name + "Hours" , this.Hours);
        localStorage.setItem(this.Name + "Minutes" , this.Minutes);
        localStorage.setItem(this.Name + "Seconds" , this.Seconds);
        localStorage.setItem(this.Name + "TotalSeconds" , this.TotalSeconds);
    }
}
class XP{
    TotalXP = 0;
    CurrentXP = 0;
    level = 1;
    constructor(Name,Amplifier){
        this.Name = Name;
        this.Amplifier = Amplifier;
        this.RequiredXP = Amplifier;
    }
    calcRequiredXP(){
        this.RequiredXP = Math.pow(this.level,2) * this.Amplifier;
    }
    addXP(amount){
        this.TotalXP+=amount;
        this.CurrentXP+=amount;
        while(this.CurrentXP>=this.RequiredXP){
            this.level++;
            this.CurrentXP-=this.RequiredXP;
            this.calcRequiredXP();
        }
        update();
    }
    load(){
        this.TotalXP = Number(localStorage[this.Name + "TotalXP"]) || this.TotalXP;
        this.CurrentXP = Number(localStorage[this.Name + "CurrentXP"]) || this.CurrentXP;
        this.level = Number(localStorage[this.Name + "level"]) || this.level;
        this.RequiredXP = Number(localStorage[this.Name + "RequiredXP"]) || this.RequiredXP;
    }
    save(){
        localStorage.setItem(this.Name + "TotalXP" , this.TotalXP);
        localStorage.setItem(this.Name + "CurrentXP" , this.CurrentXP);
        localStorage.setItem(this.Name + "level" , this.level);
        localStorage.setItem(this.Name + "RequiredXP" , this.RequiredXP);
    }
}